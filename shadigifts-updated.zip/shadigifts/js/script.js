/* ShaadiGifts — shared script: layout injection, product data, wishlist, forms */
(function () {
  'use strict';

  /* ---------- Icons ---------- */
  var I = {
    tag: '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M6 6h17l19 19-17 17L6 23z"/><circle cx="16" cy="16" r="3"/></svg>',
    sort: '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 40V8M7 16l8-8 8 8M33 8v32M25 32l8 8 8-8"/></svg>',
    bookmark: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M6 3h12v18l-6-4-6 4z"/></svg>',
    pencil: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20l1-5L16 4l4 4L9 19zM13 7l4 4"/></svg>',
    heart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/></svg>',
    arrow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5 9-10"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v6M14 11v6"/></svg>',
    globe: '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="24" cy="24" r="19"/><ellipse cx="24" cy="24" rx="8" ry="19"/><path d="M5 24h38M8 14h32M8 34h32"/></svg>',
    box: '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M24 4l17 8v24l-17 8-17-8V12z"/><path d="M7 12l17 8 17-8M24 20v24M15.5 8l17 8"/></svg>',
    gift: '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"><rect x="6" y="18" width="36" height="8" rx="1.5"/><path d="M9 26v16h30V26M24 18v24M24 18c-4-9-13-8-11-3 1 3 7 3 11 3zm0 0c4-9 13-8 11-3-1 3-7 3-11 3z"/></svg>',
    truck: '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"><path d="M4 11h27v23H4zM31 18h9l5 7v9H31z"/><circle cx="14" cy="36" r="4" fill="#FDF7F0"/><circle cx="37" cy="36" r="4" fill="#FDF7F0"/></svg>',
    pen: '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"><path d="M8 40l2-9L32 9l7 7-22 22zM28 13l7 7M8 40h12"/></svg>',
    support: '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"><path d="M10 28v-4a14 14 0 0 1 28 0v4"/><rect x="6" y="26" width="7" height="12" rx="3"/><rect x="35" y="26" width="7" height="12" rx="3"/><path d="M38 38c0 5-6 6-12 6"/></svg>',
    cal: '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"><rect x="6" y="9" width="36" height="33" rx="4"/><path d="M6 19h36M15 5v8M33 5v8"/><path d="M15 27h2M23 27h2M31 27h2M15 34h2M23 34h2M31 34h2" stroke-width="3"/></svg>',
    doc: '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"><path d="M12 5h18l8 8v30H12z"/><path d="M30 5v8h8M18 22h14M18 29h14M18 36h9"/></svg>',
    wa: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm5.2 14c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.2-4.6-4-4.7-4.2-.1-.2-1.1-1.5-1.1-2.8s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.4 0 .5l-.4.6c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.1 1 2.1 1.300 2.4 1.5.3.1.5.1.6-.1l.9-1.100c.2-.3.4-.2.6-.1l1.900.9c.3.1.5.2.5.3.1.2.1.800-.1 1.400z"/></svg>',
    phone: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M6.6 10.8a15 15 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11 11 0 0 0 3.600.6 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.500a1 1 0 0 1 1 1c0 1.300.2 2.500.6 3.600a1 1 0 0 1-.25 1z"/></svg>',
    plane: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M21 16v-2l-8-5V3.500a1.500 1.500 0 0 0-3 0V9l-8 5v2l8-2.500V19l-2 1.500V22l3.500-1 3.500 1v-1.500L13 19v-5.500z"/></svg>',
    shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 3l8 3v6c0 5-3.500 8-8 9-4.500-1-8-4-8-9V6z"/><path d="M8.500 12l2.500 2.500 4.500-5" stroke-linecap="round"/></svg>',
    globeS: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/></svg>'
  };

  /* ---------- Gift illustrations (placeholder art — swap for real photos in /images) ---------- */
  var PAL = {
    crimson: { base: '#C21F4A', lid: '#A3153A', rib: '#F1CB78', acc: '#F1CB78' },
    gold:    { base: '#E8C67A', lid: '#D9B05A', rib: '#B8862B', acc: '#FFF3D0' },
    pink:    { base: '#F29AB8', lid: '#E8789F', rib: '#FFD7E4', acc: '#FFF' },
    teal:    { base: '#1F6F72', lid: '#165659', rib: '#E8C67A', acc: '#E8C67A' },
    cream:   { base: '#F6E6C8', lid: '#EBD3A4', rib: '#C21F4A', acc: '#B8862B' },
    maroon:  { base: '#7A1230', lid: '#5B0C23', rib: '#E3C27A', acc: '#E3C27A' }
  };
  var uid = 0;
  function bow(cx, cy, c) {
    return '<g><path d="M' + cx + ' ' + cy + 'C' + (cx - 62) + ' ' + (cy - 62) + ' ' + (cx - 92) + ' ' + (cy - 6) + ' ' + cx + ' ' + cy + 'z" fill="' + c.rib + '"/>' +
      '<path d="M' + cx + ' ' + cy + 'C' + (cx + 62) + ' ' + (cy - 62) + ' ' + (cx + 92) + ' ' + (cy - 6) + ' ' + cx + ' ' + cy + 'z" fill="' + c.rib + '"/>' +
      '<path d="M' + cx + ' ' + cy + 'l-26 38 14 4zM' + cx + ' ' + cy + 'l26 38-14 4z" fill="' + c.rib + '" opacity=".85"/>' +
      '<circle cx="' + cx + '" cy="' + cy + '" r="11" fill="' + c.rib + '" stroke="rgba(0,0,0,.15)"/></g>';
  }
  function dots(id, c) {
    return '<pattern id="p' + id + '" width="22" height="22" patternUnits="userSpaceOnUse"><circle cx="6" cy="6" r="2.2" fill="' + c.acc + '" opacity=".55"/><circle cx="17" cy="17" r="2.2" fill="' + c.acc + '" opacity=".55"/><path d="M11 3v6M8 6h6" stroke="' + c.acc + '" opacity=".5"/></pattern>';
  }
  function art(kind, pal) {
    var c = PAL[pal] || PAL.crimson, id = ++uid, g = '';
    if (kind === 'box') {
      g = '<defs>' + dots(id, c) + '</defs><ellipse cx="200" cy="262" rx="130" ry="12" fill="rgba(91,12,35,.14)"/>' +
        '<rect x="100" y="140" width="200" height="118" rx="8" fill="' + c.base + '"/><rect x="100" y="140" width="200" height="118" rx="8" fill="url(#p' + id + ')"/>' +
        '<rect x="90" y="120" width="220" height="34" rx="8" fill="' + c.lid + '"/><rect x="90" y="120" width="220" height="34" rx="8" fill="url(#p' + id + ')" opacity=".6"/>' +
        '<rect x="187" y="120" width="26" height="138" fill="' + c.rib + '" opacity=".95"/>' + bow(200, 118, c) +
        '<rect x="214" y="170" width="46" height="30" rx="4" fill="#FFF8EC" transform="rotate(8 237 185)"/><text x="237" y="190" font-size="12" text-anchor="middle" fill="#7A1230" font-family="serif" transform="rotate(8 237 185)">S&amp;R</text>';
    } else if (kind === 'potli') {
      function p(x, s, col, col2) {
        return '<g transform="translate(' + x + ' 0) scale(' + s + ')" style="transform-origin:center"><path d="M110 100c-34 40-48 90-14 138 30 22 78 22 108 0 34-48 20-98-14-138z" fill="' + col + '"/><path d="M110 100c-34 40-48 90-14 138 30 22 78 22 108 0 34-48 20-98-14-138z" fill="url(#p' + id + ')"/><path d="M104 104c22-14 50-14 72 0l-6 12c-20-10-40-10-60 0z" fill="' + col2 + '"/><path d="M130 112c-10-24-6-40 6-42M170 112c10-24 6-40-6-42" stroke="' + c.acc + '" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M150 236v22" stroke="' + c.acc + '" stroke-width="3"/><circle cx="150" cy="264" r="6" fill="' + c.acc + '"/></g>';
      }
      g = '<defs>' + dots(id, { acc: '#F1CB78' }) + '</defs><ellipse cx="200" cy="262" rx="140" ry="12" fill="rgba(91,12,35,.14)"/>' + p(-10, 1, '#D1285A', '#A3153A') + p(105, .88, '#F2DDB4', '#D9B05A');
    } else if (kind === 'hamper') {
      g = '<defs>' + dots(id, c) + '</defs><ellipse cx="200" cy="268" rx="120" ry="11" fill="rgba(91,12,35,.14)"/>' +
        '<path d="M120 120c10-70 150-70 160 0" fill="none" stroke="#B9873A" stroke-width="9" stroke-linecap="round"/>' +
        '<rect x="152" y="110" width="30" height="62" rx="6" fill="#FFF3D9"/><rect x="152" y="104" width="30" height="12" rx="4" fill="#C79A3C"/>' +
        '<rect x="196" y="100" width="34" height="72" rx="6" fill="#F5D7C6"/><rect x="196" y="93" width="34" height="13" rx="4" fill="#C79A3C"/>' +
        '<rect x="238" y="116" width="28" height="56" rx="6" fill="#E9B5A0"/><rect x="238" y="110" width="28" height="12" rx="4" fill="#C79A3C"/>' +
        '<path d="M100 160h200l-22 98H122z" fill="#D9A95A"/><path d="M104 180h192M110 204h180M116 228h168" stroke="#B9873A" stroke-width="3"/>' +
        '<path d="M140 160l12 98M180 160l4 98M220 160l-4 98M260 160l-12 98" stroke="#B9873A" stroke-width="3" opacity=".7"/>' +
        '<rect x="100" y="152" width="200" height="14" rx="7" fill="#C79A3C"/>';
    } else if (kind === 'jars') {
      function j(x, s) {
        return '<g transform="translate(' + x + ' 0) scale(' + s + ')"><rect x="90" y="86" width="64" height="14" rx="5" fill="#C79A3C"/><circle cx="122" cy="82" r="8" fill="#E3C27A"/><path d="M96 100h52c10 12 12 80 0 118-10 12-42 12-52 0-12-38-10-106 0-118z" fill="#FFF3DD"/><path d="M96 100h52c10 12 12 80 0 118-10 12-42 12-52 0-12-38-10-106 0-118z" fill="url(#p' + id + ')"/><circle cx="122" cy="160" r="18" fill="#FFFBF0" stroke="#C79A3C"/><path d="M114 160h16M122 152v16" stroke="#C21F4A" stroke-width="2"/></g>';
      }
      g = '<defs>' + dots(id, { acc: '#E57A9B' }) + '</defs><ellipse cx="200" cy="262" rx="120" ry="11" fill="rgba(91,12,35,.14)"/>' + j(20, 1) + j(120, 1);
    } else if (kind === 'candle') {
      g = '<defs><pattern id="p' + id + '" width="20" height="20" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="10" height="10" fill="#FFF0B8" opacity=".8"/></pattern><radialGradient id="r' + id + '"><stop offset="0" stop-color="#FFE9A0" stop-opacity=".9"/><stop offset="1" stop-color="#FFE9A0" stop-opacity="0"/></radialGradient></defs>' +
        '<ellipse cx="200" cy="264" rx="90" ry="10" fill="rgba(91,12,35,.14)"/><circle cx="200" cy="150" r="90" fill="url(#r' + id + ')"/>' +
        '<path d="M142 140h116l-10 112H152z" fill="#D9A93F"/><path d="M142 140h116l-10 112H152z" fill="url(#p' + id + ')"/><ellipse cx="200" cy="140" rx="58" ry="10" fill="#B8862B"/>' +
        '<path d="M200 80c14 18 14 34 0 44-14-10-14-26 0-44z" fill="#FFB02E"/><path d="M200 100c6 8 6 16 0 20-6-4-6-12 0-20z" fill="#FFF3B0"/>';
    } else if (kind === 'tin') {
      g = '<ellipse cx="200" cy="268" rx="130" ry="12" fill="rgba(91,12,35,.14)"/>' +
        '<ellipse cx="170" cy="196" rx="112" ry="46" fill="#E6C27A"/><ellipse cx="170" cy="186" rx="104" ry="40" fill="#C48A3C"/>' +
        '<g fill="#B5651D"><circle cx="120" cy="180" r="11"/><circle cx="150" cy="170" r="11"/><circle cx="182" cy="176" r="11"/><circle cx="210" cy="188" r="11"/><circle cx="140" cy="198" r="11"/><circle cx="172" cy="200" r="11"/></g><g fill="#E8C67A"><circle cx="135" cy="184" r="9"/><circle cx="196" cy="192" r="9"/><circle cx="160" cy="186" r="8"/></g>' +
        '<ellipse cx="270" cy="150" rx="62" ry="44" fill="#F3DDA6" transform="rotate(-18 270 150)"/><ellipse cx="270" cy="150" rx="50" ry="34" fill="none" stroke="#D3A24C" stroke-width="3" transform="rotate(-18 270 150)"/>';
    } else if (kind === 'trousseau') {
      g = '<defs>' + dots(id, c) + '</defs><ellipse cx="200" cy="268" rx="140" ry="11" fill="rgba(91,12,35,.14)"/>' +
        '<rect x="70" y="170" width="150" height="88" rx="8" fill="' + c.base + '"/><rect x="70" y="170" width="150" height="88" rx="8" fill="url(#p' + id + ')"/><rect x="60" y="154" width="170" height="26" rx="6" fill="' + c.lid + '"/><rect x="132" y="154" width="22" height="104" fill="' + c.rib + '"/>' +
        '<rect x="196" y="120" width="130" height="138" rx="8" fill="#FFF3DD" stroke="#D9B05A" stroke-width="3"/><rect x="196" y="120" width="130" height="30" fill="#E8C67A"/><circle cx="240" cy="200" r="20" fill="#E57A9B" opacity=".7"/><circle cx="282" cy="214" r="24" fill="#C21F4A" opacity=".5"/><circle cx="262" cy="176" r="14" fill="#E3C27A"/>';
    }
    return '<svg viewBox="0 0 400 300" role="img" aria-label="' + kind + ' gift illustration" preserveAspectRatio="xMidYMid slice">' + g + '</svg>';
  }

  /* ---------- Data ---------- */
  var CATIMG = {"function-gifts":"function-jars","trousseau-packing":"trousseau","return-gifts":"cat-return","welcome-hampers":"cat-hampers","vip-family-gifts":"cat-vip","bridal-party-gifts":"cat-bridal"};
  var CATS = {
    'return-gifts': { name: 'Return Gifts', art: 'potli', pal: 'crimson' },
    'welcome-hampers': { name: 'Welcome Hampers', art: 'hamper', pal: 'gold' },
    'vip-family-gifts': { name: 'VIP & Family Gifts', art: 'box', pal: 'gold' },
    'bridal-party-gifts': { name: 'Bridal Party Gifts', art: 'box', pal: 'pink' },
    'function-gifts': { name: 'Function Gifts', art: 'jars', pal: 'cream' },
    'trousseau-packing': { name: 'Trousseau Packing', art: 'trousseau', pal: 'maroon' }
  };
  var FUNCS = ['Ring Ceremony', 'Haldi', 'Mehendi', 'Sangeet', 'Wedding', 'Reception'];
  var TYPES = ['Bags & Potlis', 'Hampers', 'Gift Boxes', 'Home Décor', 'Food & Treats'];
  var P = [
    ['traditional-potli-gift', 'Traditional Potli Gift', 'return-gifts', 399, ['Haldi', 'Mehendi', 'Wedding'], 'Bags & Potlis', 'potli', 'crimson', 'Elegant potli bags, perfect for wedding guests.'],
    ['elegant-gift-box', 'Elegant Gift Box', 'return-gifts', 799, ['Ring Ceremony', 'Wedding', 'Reception'], 'Gift Boxes', 'box', 'gold', 'A gold-foil gift box with satin ribbon and your monogram.'],
    ['scented-candle-set', 'Scented Candle Set', 'return-gifts', 899, ['Ring Ceremony', 'Sangeet', 'Reception'], 'Home Décor', 'candle', 'gold', 'A charming and useful gift for your celebrations.'],
    ['dry-fruit-keepsake', 'Dry Fruit Keepsake', 'return-gifts', 1199, ['Ring Ceremony', 'Wedding', 'Reception'], 'Food & Treats', 'tin', 'gold', 'Premium dry fruits in a reusable keepsake round box.'],
    ['royal-gift-box', 'Royal Gift Box', 'return-gifts', 1499, ['Ring Ceremony', 'Wedding', 'Reception'], 'Gift Boxes', 'box', 'teal', 'A royal teal-and-gold box for your most valued guests.'],
    ['decorative-candle-holder', 'Decorative Candle Holder', 'return-gifts', 599, ['Mehendi', 'Sangeet'], 'Home Décor', 'candle', 'gold', 'A cut-work golden holder that glows beautifully.'],
    ['tea-snack-jar-set', 'Tea & Snack Jar Set', 'return-gifts', 1099, ['Haldi', 'Mehendi'], 'Food & Treats', 'jars', 'cream', 'Hand-painted floral jars filled with tea and snacks.'],
    ['mini-hamper', 'Mini Hamper', 'return-gifts', 1299, ['Ring Ceremony', 'Haldi', 'Sangeet'], 'Hampers', 'hamper', 'gold', 'A mini woven basket of curated gourmet treats.'],
    ['premium-welcome-hamper', 'Premium Welcome Hamper', 'welcome-hampers', 1499, ['Ring Ceremony', 'Wedding'], 'Hampers', 'hamper', 'gold', 'A thoughtful hamper for a warm welcome at the hotel.'],
    ['festive-gift-hamper', 'Festive Gift Hamper', 'welcome-hampers', 2499, ['Wedding', 'Reception'], 'Hampers', 'hamper', 'crimson', 'A curated mix of gourmet treats and keepsakes.'],
    ['guest-room-welcome-kit', 'Guest Room Welcome Kit', 'welcome-hampers', 999, ['Wedding'], 'Hampers', 'jars', 'cream', 'Snacks, a handwritten note and the day\'s itinerary, ready in every room.'],
    ['destination-welcome-tray', 'Destination Welcome Tray', 'welcome-hampers', 1799, ['Wedding', 'Sangeet'], 'Hampers', 'tin', 'gold', 'A welcome tray tuned to your destination and theme.'],
    ['dry-fruit-gift-box', 'Dry Fruit Gift Box', 'vip-family-gifts', 1899, ['Ring Ceremony', 'Wedding', 'Reception'], 'Food & Treats', 'box', 'teal', 'Premium dry fruits in a royal keepsake box.'],
    ['family-heirloom-box', 'Family Heirloom Box', 'vip-family-gifts', 2999, ['Ring Ceremony', 'Wedding'], 'Gift Boxes', 'box', 'maroon', 'A luxurious box with a personalised family message.'],
    ['silver-keepsake-set', 'Silver Keepsake Set', 'vip-family-gifts', 3499, ['Ring Ceremony', 'Wedding'], 'Home Décor', 'candle', 'gold', 'A premium keepsake set for elders and close family.'],
    ['vip-gourmet-hamper', 'VIP Gourmet Hamper', 'vip-family-gifts', 2799, ['Ring Ceremony', 'Wedding', 'Reception'], 'Hampers', 'hamper', 'maroon', 'Gourmet treats in a statement basket for VIP guests.'],
    ['personalized-gift-box', 'Personalized Gift Box', 'bridal-party-gifts', 1299, ['Ring Ceremony', 'Haldi', 'Mehendi', 'Sangeet'], 'Gift Boxes', 'box', 'pink', 'Customised gifts with names and special messages.'],
    ['bridesmaid-getting-ready-box', 'Bridesmaid Getting-Ready Box', 'bridal-party-gifts', 1799, ['Haldi', 'Wedding'], 'Gift Boxes', 'box', 'pink', 'Robes, treats and a note for the morning of the wedding.'],
    ['groomsmen-gift-box', 'Groomsmen Gift Box', 'bridal-party-gifts', 1599, ['Sangeet', 'Wedding'], 'Gift Boxes', 'box', 'teal', 'A sharp, personalised box for the groom\'s crew.'],
    ['bridal-party-potli', 'Bridal Party Potli', 'bridal-party-gifts', 699, ['Mehendi', 'Haldi'], 'Bags & Potlis', 'potli', 'crimson', 'A potli with a personalised charm for each bridesmaid.'],
    ['function-gift-jar-set', 'Function Gift Jar Set', 'function-gifts', 1099, ['Mehendi', 'Haldi'], 'Food & Treats', 'jars', 'cream', 'Painted jars themed to your function.'],
    ['mehendi-favour-bag', 'Mehendi Favour Bag', 'function-gifts', 499, ['Mehendi'], 'Bags & Potlis', 'potli', 'crimson', 'A bright favour bag with sweets and a mehendi cone.'],
    ['sangeet-night-box', 'Sangeet Night Box', 'function-gifts', 899, ['Sangeet'], 'Gift Boxes', 'box', 'crimson', 'Treats and a glow keepsake for a dance-all-night sangeet.'],
    ['haldi-ritual-kit', 'Haldi Ritual Kit', 'function-gifts', 799, ['Haldi'], 'Hampers', 'tin', 'gold', 'A sunny kit of ubtan, flowers and a keepsake.'],
    ['trousseau-packing-set', 'Trousseau Packing Set', 'trousseau-packing', 3999, ['Wedding'], 'Gift Boxes', 'trousseau', 'maroon', 'Beautifully packed trousseau with themed boxes and tags.'],
    ['saree-gift-packing', 'Saree & Outfit Packing', 'trousseau-packing', 1999, ['Wedding'], 'Gift Boxes', 'trousseau', 'crimson', 'Saree and outfit presentation boxes with satin finish.'],
    ['jewellery-presentation-box', 'Jewellery Presentation Box', 'trousseau-packing', 2499, ['Wedding'], 'Gift Boxes', 'box', 'maroon', 'Lined presentation boxes for jewellery sets.'],
    ['sweets-and-tray-set', 'Sweets & Tray Set', 'trousseau-packing', 2299, ['Wedding'], 'Food & Treats', 'tin', 'gold', 'Decorated trays and boxes for the sweets that travel with the bride.']
  ].map(function (r) {
    return { id: r[0], name: r[1], cat: r[2], price: r[3], funcs: r[4], type: r[5], art: r[6], pal: r[7], desc: r[8] };
  });
  var IMG = {"traditional-potli-gift":"potli","elegant-gift-box":"elegant-box","scented-candle-set":"candle-set","dry-fruit-keepsake":"dry-fruit-keepsake","royal-gift-box":"royal-box","decorative-candle-holder":"candle-holder","tea-snack-jar-set":"tea-jars","mini-hamper":"mini-hamper","premium-welcome-hamper":"cat-hampers","festive-gift-hamper":"festive-hamper","guest-room-welcome-kit":"mini-hamper","destination-welcome-tray":"dry-fruit-keepsake","dry-fruit-gift-box":"thumb-dryfruit-box","family-heirloom-box":"cat-vip","silver-keepsake-set":"candle-holder","vip-gourmet-hamper":"festive-hamper","personalized-gift-box":"cat-bridal","bridesmaid-getting-ready-box":"cat-bridal","groomsmen-gift-box":"royal-box","bridal-party-potli":"potli","function-gift-jar-set":"function-jars","mehendi-favour-bag":"potli","sangeet-night-box":"candle-set","haldi-ritual-kit":"tea-jars","trousseau-packing-set":"trousseau","saree-gift-packing":"trousseau","jewellery-presentation-box":"elegant-box","sweets-and-tray-set":"dry-fruit-keepsake"};
  function pic(p, eager) { var f = IMG[p.id]; return f ? "<img src=\"images/products/" + f + ".jpg\" alt=\"" + esc(p.name) + "\" width=\"337\" height=\"178\"" + (eager ? "" : " loading=\"lazy\"") + ">" : art(p.art, p.pal); }
  function byId(id) { return P.filter(function (p) { return p.id === id; })[0]; }
  function inr(n) { return '₹' + n.toLocaleString('en-IN'); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ---------- Wishlist store ---------- */
  var KEY = 'sg_wishlist_v1';
  function load() { try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch (e) { return []; } }
  function save(l) { try { localStorage.setItem(KEY, JSON.stringify(l)); } catch (e) {} refreshCount(); document.dispatchEvent(new Event('wl:change')); }
  function has(id) { return load().some(function (x) { return x.id === id; }); }
  function add(id, qty) {
    var l = load();
    if (!l.some(function (x) { return x.id === id; })) { l.push({ id: id, qty: qty || 25, note: '' }); save(l); }
  }
  function remove(id) { save(load().filter(function (x) { return x.id !== id; })); }
  function toggle(id) {
    if (has(id)) { remove(id); toast('Removed from Wishlist', byId(id).name + ' has been removed.', false); return false; }
    add(id); toast('Added to your Wishlist', byId(id).name + ' has been saved.', true); return true;
  }
  function refreshCount() {
    var n = load().length;
    document.querySelectorAll('[data-wl-count]').forEach(function (e) { e.textContent = n; });
  }

  /* ---------- Toast ---------- */
  var toastEl, toastT;
  function toast(title, msg, link) {
    if (!toastEl) { toastEl = document.createElement('div'); toastEl.className = 'toast'; toastEl.setAttribute('role', 'status'); toastEl.setAttribute('aria-live', 'polite'); document.body.appendChild(toastEl); }
    toastEl.innerHTML = '<span class="tk">' + I.check + '</span><div><b>' + esc(title) + '</b>' + esc(msg) + '</div>' + (link ? '<a href="wishlist.html">View Wishlist</a>' : '') + '<button class="tx" aria-label="Dismiss">×</button>'; toastEl.querySelector(".tx").onclick = function () { toastEl.classList.remove("show"); };
    toastEl.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(function () { toastEl.classList.remove('show'); }, 4200);
  }

  /* ---------- Layout ---------- */
  var LOGO = '<svg viewBox="0 0 60 44" fill="none" stroke="#7A1230" stroke-width="2.6" stroke-linecap="round"><ellipse cx="21" cy="22" rx="12" ry="17" transform="rotate(-22 21 22)"/><ellipse cx="39" cy="22" rx="12" ry="17" transform="rotate(22 39 22)"/><ellipse cx="30" cy="22" rx="7" ry="13" stroke="#B8862B"/></svg>';
  /* ---------- Mega menu (Collections) ---------- */
  function megaHTML() {
    var keys = Object.keys(CATS);
    var cols = keys.map(function (k) {
      var items = P.filter(function (p) { return p.cat === k; });
      return '<div class="mg-col"><a class="mg-h" href="collections.html?cat=' + k + '"><img src="images/products/' + CATIMG[k] + '.jpg" alt="" width="44" height="44" loading="lazy"><span>' + CATS[k].name.replace('&', '&amp;') + '<em>' + items.length + ' gifts</em></span></a><ul>' +
        items.map(function (p) { return '<li><a href="product.html?id=' + p.id + '">' + esc(p.name) + '</a></li>'; }).join('') +
        '<li class="all"><a href="collections.html?cat=' + k + '">View all ' + I.arrow + '</a></li></ul></div>';
    }).join('');
    var PRS = [['100-999', '₹100 – ₹999'], ['1000-1999', '₹1,000 – ₹1,999'], ['2000-2999', '₹2,000 – ₹2,999'], ['3000-99999', '₹3,000 &amp; above']];
    function chips(title, arr) { return '<div class="mg-row"><b>' + title + '</b>' + arr.join('') + '</div>'; }
    var fn = FUNCS.map(function (x) { return '<a href="collections.html?fn=' + encodeURIComponent(x) + '">' + x + '</a>'; });
    var ty = TYPES.map(function (x) { return '<a href="collections.html?ty=' + encodeURIComponent(x) + '">' + x.replace('&', '&amp;') + '</a>'; });
    var pr = PRS.map(function (x) { return '<a href="collections.html?pr=' + x[0] + '">' + x[1] + '</a>'; });
    return '<div class="mega"><div class="mega-in"><div class="mg-grid">' + cols + '</div><div class="mg-foot">' + chips('Shop by Function', fn) + chips('Shop by Gift Type', ty) + chips('Shop by Price', pr) + '</div></div></div>';
  }
  function drawerColl(page) {
    return '<details class="d-acc"' + (page === 'collections' ? ' open' : '') + '><summary>Collections</summary><div class="d-sub"><a href="collections.html">All Collections</a>' +
      Object.keys(CATS).map(function (k) { return '<a href="collections.html?cat=' + k + '">' + CATS[k].name.replace('&', '&amp;') + '</a>'; }).join('') + '</div></details>';
  }
  function header(page) {
    var nav = [['index.html', 'Home', 'home'], ['collections.html', 'Collections', 'collections'], ['services.html', 'Services', 'services'], ['planner.html', 'Wedding Gifting Planner', 'planner'], ['about.html', 'About Us', 'about']];
    var TAGLINK = '<a class="nav-tag" href="collections.html?pr=100-999"><span class="nt-ic">' + I.tag + '</span>₹100 – ₹999</a>';
    var links = nav.map(function (n) { var a = '<a href="' + n[0] + '"' + (page === n[2] ? ' class="on" aria-current="page"' : '') + '>' + n[1] + (n[2] === 'collections' ? '<svg class="chev" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 4l4 4 4-4"/></svg>' : '') + '</a>'; return n[2] === 'collections' ? '<div class="has-mega">' + a + megaHTML() + '</div>' : a; }).join('') + TAGLINK;
    var dlinks = nav.map(function (n) { if (n[2] === 'collections') return drawerColl(page); return '<a href="' + n[0] + '"' + (page === n[2] ? ' class="on"' : '') + '>' + n[1] + '</a>'; }).join('') + '<a href="wishlist.html"' + (page === 'wishlist' ? ' class="on"' : '') + '>My Wishlist (<span data-wl-count>0</span>)</a>' + TAGLINK;
    return '<div class="topbar"><div class="wrap"><ul class="tb-left"><li>' + I.globeS + 'Serving India &amp; Worldwide</li><li>' + I.plane + 'International Delivery</li><li>' + I.shield + 'Quality Assured</li></ul>' +
      '<ul class="tb-right"><li><a href="https://wa.me/919876543210" style="display:flex;gap:8px;align-items:center"><span style="width:18px;height:18px;color:#6BE08E;display:block">' + I.wa + '</span>Chat on WhatsApp</a></li><li><a href="tel:+919876543210" style="display:flex;gap:8px;align-items:center"><span style="width:18px;height:18px;display:block;color:var(--gold-l)">' + I.phone + '</span>+91 98765 43210</a></li></ul></div></div>' +
      '<header class="site-header"><div class="wrap"><a class="logo" href="index.html" aria-label="ShaadiGifts home">' + LOGO + '<span><b>ShaadiGifts</b><small>The Wedding Gifting Concierge</small></span></a>' +
      '<nav class="nav" aria-label="Main">' + links + '</nav><div class="hdr-actions"><a class="wl-pill" href="wishlist.html">' + I.heart + '<span>Wishlist (<span data-wl-count>0</span>)</span></a><a class="btn btn-primary btn-sm" href="planner.html">Plan My Wedding Gifting ' + I.arrow + '</a></div>' +
      '<div class="mwl"><a class="wl-mini" href="wishlist.html" aria-label="Wishlist">' + I.heart + '<em data-wl-count>0</em></a><button class="burger" aria-label="Open menu" aria-expanded="false"><span></span></button></div></div></header>' +
      '<div class="drawer" id="drawer"><nav aria-label="Mobile"><button class="close" aria-label="Close menu">×</button>' + dlinks + '<a class="btn btn-primary" href="planner.html">Plan My Wedding Gifting ' + I.arrow + '</a></nav></div>';
  }
  function footer() {
    return '<footer class="site-footer"><div class="wrap"><div><a class="logo" href="index.html">' + LOGO.replace('#7A1230', '#E3C27A') + '<span><b>ShaadiGifts</b><small>The Wedding Gifting Concierge</small></span></a><p style="margin-top:14px">We curate, personalize, package and deliver your wedding gifts — on time, at your venue, anywhere in the world.</p></div>' +
      '<div><h4>Explore</h4><ul><li><a href="index.html">Home</a></li><li><a href="collections.html">Collections</a></li><li><a href="services.html">Services</a></li><li><a href="planner.html">Wedding Gifting Planner</a></li><li><a href="about.html">About Us</a></li></ul></div>' +
      '<div><h4>Collections</h4><ul>' + Object.keys(CATS).map(function (k) { return '<li><a href="collections.html?cat=' + k + '">' + CATS[k].name.replace('&', '&amp;') + '</a></li>'; }).join('') + '</ul></div>' +
      '<div><h4>Get in Touch</h4><ul><li><a href="tel:+919876543210">+91 98765 43210</a></li><li><a href="https://wa.me/919876543210">Chat on WhatsApp</a></li><li><a href="wishlist.html">My Wishlist (<span data-wl-count>0</span>)</a></li></ul><p style="margin-top:12px;font-size:.85rem;opacity:.8">Gifts are not sold online — build a wishlist and request a personalised proposal.</p></div></div>' +
      '<div class="copy">© ' + new Date().getFullYear() + ' ShaadiGifts. All rights reserved.</div></footer>';
  }
  function initLayout() {
    var page = document.body.getAttribute('data-page');
    var h = document.getElementById('site-header'), f = document.getElementById('site-footer');
    if (h) h.outerHTML = header(page);
    if (f) f.outerHTML = footer();
    var dr = document.getElementById('drawer'), b = document.querySelector('.burger');
    function setD(o) { dr.classList.toggle('open', o); b.setAttribute('aria-expanded', o); document.body.style.overflow = o ? 'hidden' : ''; }
    if (b) { b.addEventListener('click', function () { setD(true); }); dr.querySelector('.close').addEventListener('click', function () { setD(false); }); dr.addEventListener('click', function (e) { if (e.target === dr) setD(false); }); }
    refreshCount();
  }

  /* ---------- Product card ---------- */
  function card(p, opt) {
    opt = opt || {};
    var on = has(p.id);
    return '<article class="pcard" data-id="' + p.id + '"><button class="heart' + (on ? ' on' : '') + '" aria-pressed="' + on + '" aria-label="' + (on ? 'Remove ' : 'Add ') + esc(p.name) + (on ? ' from' : ' to') + ' wishlist" data-heart="' + p.id + '">' + I.heart + '</button>' +
      '<a class="art" href="product.html?id=' + p.id + '" tabindex="-1" aria-hidden="true">' + pic(p) + '</a><div class="body"><h3><a href="product.html?id=' + p.id + '">' + esc(p.name) + '</a></h3>' +
      (opt.desc ? '<p class="desc">' + esc(p.desc) + '</p>' : '') + '<p class="price">Starting from <b>' + inr(p.price) + '</b></p><div class="acts">' +
      (opt.wishBtn ? '<button class="btn btn-ghost btn-sm' + (on ? ' added' : '') + '" data-wishbtn="' + p.id + '">' + I.heart.replace('<svg ', '<svg style="width:16px;height:16px" ') + (on ? 'Added to Wishlist' : 'Add to Wishlist') + '</button>' : '') +
      '<a class="btn btn-ghost btn-sm" href="product.html?id=' + p.id + '">View Details ' + I.arrow + '</a></div></div></article>';
  }
  function bindCards(root) {
    root.addEventListener('click', function (e) {
      var t = e.target.closest('[data-heart],[data-wishbtn]');
      if (!t) return;
      var id = t.getAttribute('data-heart') || t.getAttribute('data-wishbtn');
      toggle(id);
      syncCards(root);
    });
  }
  function syncCards(root) {
    root.querySelectorAll('.pcard').forEach(function (c) {
      var id = c.getAttribute('data-id'), on = has(id), h = c.querySelector('[data-heart]'), w = c.querySelector('[data-wishbtn]');
      h.classList.toggle('on', on); h.setAttribute('aria-pressed', on);
      if (w) { w.classList.toggle('added', on); w.lastChild.textContent = on ? 'Added to Wishlist' : 'Add to Wishlist'; }
    });
  }

  /* ---------- Page: home ---------- */
  function pageHome() {
    var el = document.getElementById('home-cats'); if (!el) return;
    var ft = document.getElementById('home-feat');
    if (ft) { ft.innerHTML = ['traditional-potli-gift', 'elegant-gift-box', 'premium-welcome-hamper', 'personalized-gift-box'].map(function (id) { return card(byId(id), {}); }).join(''); bindCards(ft); }
    el.innerHTML = ['return-gifts', 'welcome-hampers', 'vip-family-gifts', 'bridal-party-gifts'].map(function (k) {
      var c = CATS[k]; return '<a class="cat-card" href="collections.html?cat=' + k + '"><div class="art"><img src="images/products/' + CATIMG[k] + '.jpg" alt="' + c.name.replace("&", "&amp;") + '" width="267" height="158" loading="lazy"></div><div class="lbl"><span>' + c.name.replace('&', '&amp;') + '</span>' + I.arrow + '</div></a>';
    }).join('');
  }

  /* ---------- Page: collections ---------- */
  function pageCollections() {
    var grid = document.getElementById('pgrid'); if (!grid) return;
    var cat = new URLSearchParams(location.search).get('cat'); if (!CATS[cat]) cat = null;
    var fbar = document.getElementById('filters'), rbar = document.getElementById('results-bar'), cg = document.getElementById('catgrid');
    var FN = '<option value="">All Functions</option>' + FUNCS.map(function (x) { return '<option>' + x + '</option>'; }).join('');
    var TY = '<option value="">All Gift Types</option>' + TYPES.map(function (x) { return '<option>' + x.replace('&', '&amp;') + '</option>'; }).join('');
    var PR = '<option value="">All Ranges</option><option value="100-999">₹100 – ₹999</option><option value="1000-1999">₹1,000 – ₹1,999</option><option value="2000-2999">₹2,000 – ₹2,999</option><option value="3000-99999">₹3,000 &amp; above</option>';
    var SO = '<option value="feat">Featured</option><option value="low">Price: Low to High</option><option value="high">Price: High to Low</option><option value="az">Name: A–Z</option>';
    function fld(icon, label, id, inner) { return '<div class="f"><span class="fi">' + icon + '</span><div><label for="' + id + '">' + label + '</label><select id="' + id + '">' + inner + '</select></div></div>'; }
    if (cat) {
      var nm = CATS[cat].name;
      document.title = nm + ' | ShaadiGifts — Wedding Gifting Concierge';
      document.getElementById('ph-title').textContent = nm;
      document.getElementById('ph-sub').textContent = 'Thoughtful and elegant gifts your guests will love.';
      var pi = document.getElementById("ph-img"); if (pi) pi.remove(); document.querySelector(".page-hero").classList.remove("has-img");
      document.getElementById('ph-eyebrow').hidden = true;
      document.getElementById('crumb-cat').innerHTML = '<i>›</i><a href="collections.html">Collections</a><i>›</i><span class="cur">' + nm.replace('&', '&amp;') + '</span>';
      fbar.innerHTML = fld(I.cal, 'Function', 'f-fn', FN) + fld(I.tag, 'Price Range', 'f-pr', PR) + fld(I.sort, 'Sort By', 'f-so', SO) + '<span class="count" id="f-count" aria-live="polite"></span>';
      rbar.hidden = true;
    } else {
      document.getElementById('crumb-cat').innerHTML = '<i>›</i><span class="cur">Collections</span>';
      document.getElementById('ph-eyebrow').hidden = true;
      fbar.innerHTML = fld(I.cal, 'Function', 'f-fn', FN) + fld(I.tag, 'Price Range (per gift)', 'f-pr', PR) + fld(I.gift, 'Gift Type', 'f-ty', TY) + '<button class="linkbtn" id="f-clear" type="button">Clear All</button>';
      rbar.innerHTML = '<span id="f-count" aria-live="polite"></span><label>Sort by: <select id="f-so">' + SO + '</select></label>';
      cg.innerHTML = Object.keys(CATS).map(function (k) { var c = CATS[k]; return '<a class="cat-card circ" href="collections.html?cat=' + k + '"><div class="art"><img src="images/products/' + CATIMG[k] + '.jpg" alt="' + c.name.replace('&', '&amp;') + '" width="267" height="158" loading="lazy"></div><div class="lbl"><span>' + c.name.replace('&', '&amp;') + '</span><i>' + I.arrow + '</i></div></a>'; }).join('');
    }
    var fFn = document.getElementById('f-fn'), fPr = document.getElementById('f-pr'), fTy = document.getElementById('f-ty'), fSo = document.getElementById('f-so');
    var qfn = new URLSearchParams(location.search).get('fn'); if (qfn && FUNCS.indexOf(qfn) > -1) fFn.value = qfn;
    var qty = new URLSearchParams(location.search).get('ty'); if (qty && fTy && TYPES.indexOf(qty) > -1) fTy.value = qty;
    var qpr = new URLSearchParams(location.search).get('pr'); if (qpr && fPr.querySelector('option[value="' + qpr + '"]')) fPr.value = qpr;
    function render() {
      var filtered = !!(cat || fFn.value || fPr.value || (fTy && fTy.value));
      if (!cat) { cg.hidden = filtered; rbar.hidden = !filtered; } grid.hidden = cat ? false : !filtered;
      var r = P.filter(function (p) {
        if (cat && p.cat !== cat) return false;
        if (fFn.value && p.funcs.indexOf(fFn.value) < 0) return false;
        if (fTy && fTy.value && p.type !== fTy.value) return false;
        if (fPr.value) { var b = fPr.value.split('-'); if (p.price < +b[0] || p.price > +b[1]) return false; }
        return true;
      });
      if (fSo.value === 'low') r.sort(function (a, b) { return a.price - b.price; });
      if (fSo.value === 'high') r.sort(function (a, b) { return b.price - a.price; });
      if (fSo.value === 'az') r.sort(function (a, b) { return a.name.localeCompare(b.name); });
      document.getElementById('f-count').textContent = cat ? r.length + (r.length === 1 ? ' Product' : ' Products') : r.length + ' Gifts Found';
      grid.className = 'pgrid' + (cat ? '' : ' detail');
      grid.innerHTML = r.length ? r.map(function (p) { return cat ? card(p, {}) : card(p, { desc: true, wishBtn: true }); }).join('') : '<div class="empty" style="grid-column:1/-1"><h3>No gifts match these filters</h3><p>Try a wider price range, or tell us what you have in mind and we will curate it for you.</p><a class="btn btn-primary" href="planner.html">Plan My Wedding Gifting</a></div>';
    }
    [fFn, fPr, fTy, fSo].forEach(function (s) { if (s) s.addEventListener('change', render); });
    var clr = document.getElementById('f-clear'); if (clr) clr.addEventListener('click', function () { fFn.value = fPr.value = fTy.value = ''; fSo.value = 'feat'; render(); });
    bindCards(grid); render();
  }

  /* ---------- Page: product ---------- */
  function pageProduct() {
    var el = document.getElementById('pd'); if (!el || document.body.getAttribute('data-page') !== 'collections') return;
    var p = byId(new URLSearchParams(location.search).get('id')) || P[0];
    document.title = p.name + ' | ShaadiGifts — Wedding Gifting Concierge';
    var c = CATS[p.cat];
    document.getElementById('crumb-cat').innerHTML = '<i>›</i><a href="collections.html">Collections</a><i>›</i><a href="collections.html?cat=' + p.cat + '">' + c.name.replace('&', '&amp;') + '</a><i>›</i><span class="cur">' + esc(p.name) + '</span>';
    function draw() {
      var on = has(p.id);
      el.innerHTML = '<div class="gal">' + pic(p, true) + '</div><div><span class="tag">' + c.name.replace('&', '&amp;') + '</span><h1 style="font-size:clamp(2rem,4vw,3rem)">' + esc(p.name) + '</h1><p class="pr">Starting from <b>' + inr(p.price) + '</b> per gift</p><p>' + esc(p.desc) + ' Every piece can be personalised with names, monograms and a message, then packed to match your wedding theme.</p>' +
        '<ul class="det"><li>Suited to: ' + p.funcs.join(', ') + '</li><li>Gift type: ' + p.type.replace('&', '&amp;') + '</li><li>Personalisation: names, monograms, custom tags and message cards</li><li>Delivered to your venue, home or hotel — India and worldwide</li></ul>' +
        '<div class="buy"><button class="btn btn-primary" id="pd-add">' + I.heart.replace('<svg ', '<svg style="width:18px;height:18px" ') + (on ? 'Remove from Wishlist' : 'Add to Wishlist') + '</button><a class="btn btn-ghost" href="wishlist.html">View Wishlist (<span data-wl-count>0</span>)</a></div>' +
        '<p class="note-i">Gifts are not sold online. Add this to your wishlist, then submit it with your wedding details for a personalised quotation. Prices are indicative; the final quote depends on quantity, personalisation and packaging.</p></div>';
      document.getElementById('pd-add').addEventListener('click', function () { toggle(p.id); draw(); refreshCount(); });
    }
    draw();
    var rel = P.filter(function (x) { return x.cat === p.cat && x.id !== p.id; }).slice(0, 4), g = document.getElementById('related');
    g.innerHTML = rel.map(function (x) { return card(x, { wishBtn: false }); }).join(''); bindCards(g);
  }

  /* ---------- Page: wishlist ---------- */
  function wlRef() { return 'SG-' + Date.now().toString(36).toUpperCase().slice(-6); }
  function pageWishlist() {
    var box = document.getElementById('wl'); if (!box) return;
    function draw() {
      var l = load();
      if (!l.length) { box.innerHTML = '<div class="empty"><h3>Your wishlist is empty</h3><p>Browse our collections and tap the heart on any gift to save it here.</p><a class="btn btn-primary" href="collections.html">Explore Collections</a></div>'; return; }
      var tot = 0;
      box.innerHTML = '<div class="wl-layout">' + l.map(function (x) {
        var p = byId(x.id); if (!p) return ''; tot += +x.qty || 0;
        return '<div class="wl-item" data-id="' + p.id + '"><div class="th">' + pic(p) + '</div><div class="info"><h3>' + esc(p.name) + '</h3><div class="meta">' + CATS[p.cat].name.replace('&', '&amp;') + ' &nbsp;|&nbsp; Starting from ' + inr(p.price) + '</div></div>' +
          '<div class="wl-ctrl"><div class="qrow"><div class="qb"><label class="ql" for="q-' + p.id + '">Quantity</label><div class="qty"><button aria-label="Decrease quantity" data-q="-5">−</button><input id="q-' + p.id + '" type="number" min="1" value="' + x.qty + '" inputmode="numeric"><button aria-label="Increase quantity" data-q="5">+</button></div></div><button class="rm" aria-label="Remove ' + esc(p.name) + '" data-rm>' + I.trash + '</button></div>' +
          '<div class="note"><span>' + I.pencil + '</span><label class="sr" for="n-' + p.id + '">Note</label><input id="n-' + p.id + '" type="text" placeholder="Add a note (optional)" value="' + esc(x.note || '') + '"></div></div></div>';
      }).join('') + '<div class="wl-sum"><span class="gi">' + I.gift + '</span><div class="st"><div class="big">Your Selection</div><div class="dis">Indicative prices only. Final quotation depends on quantity, customization and packaging.</div></div><div class="tt"><b>' + l.length + '</b> Products <i>|</i> Total Quantity: <b class="q">' + tot + '</b></div></div>' +
        '<div class="wl-actions"><a class="btn btn-ghost" href="collections.html">← Continue Exploring Collections</a><button class="btn btn-primary" id="req">Request Personalized Quote ' + I.arrow + '</button></div></div>';
    }
    box.addEventListener('click', function (e) {
      var it = e.target.closest('.wl-item');
      if (e.target.closest('#req')) { openQuote(); return; }
      if (!it) return;
      var id = it.getAttribute('data-id'), l = load();
      if (e.target.closest('[data-rm]')) { remove(id); draw(); return; }
      var q = e.target.closest('[data-q]');
      if (q) { var x = l.filter(function (y) { return y.id === id; })[0]; x.qty = Math.max(1, (+x.qty || 1) + +q.getAttribute('data-q')); save(l); draw(); }
    });
    box.addEventListener('change', function (e) {
      var it = e.target.closest('.wl-item'); if (!it) return;
      var id = it.getAttribute('data-id'), l = load(), x = l.filter(function (y) { return y.id === id; })[0];
      if (e.target.type === 'number') { x.qty = Math.max(1, parseInt(e.target.value, 10) || 1); save(l); draw(); } else { x.note = e.target.value; save(l); }
    });
    draw();

    var dlg = document.getElementById('quote'), form = document.getElementById('quote-form'), ok = document.getElementById('quote-ok');
    function openQuote() { form.hidden = false; ok.hidden = true; dlg.showModal(); }
    dlg.querySelector('.x').addEventListener('click', function () { dlg.close(); });
    dlg.addEventListener('click', function (e) { if (e.target === dlg) dlg.close(); });
    dlg.querySelectorAll('.done').forEach(function (b) { b.addEventListener('click', function () { dlg.close(); }); });
    validate(form, function () {
      var l = load(), d = {}; new FormData(form).forEach(function (v, k) { d[k] = v; });
      var ref = wlRef(), req = { ref: ref, contact: d, items: l.map(function (x) { var p = byId(x.id); return { id: x.id, name: p && p.name, qty: x.qty, note: x.note }; }) };
      try { var all = JSON.parse(localStorage.getItem('sg_requests') || '[]'); all.push(req); localStorage.setItem('sg_requests', JSON.stringify(all)); } catch (e) {}
      /* TODO: POST `req` to the real enquiry endpoint / CRM when the backend is connected. */
      form.hidden = true; ok.hidden = false; ok.querySelector('.ref').textContent = 'Reference: ' + ref;
      save([]); draw();
    });
  }

  /* ---------- Generic validation ---------- */
  function validate(form, onOk) {
    form.setAttribute('novalidate', '');
    form.addEventListener('submit', function (e) {
      e.preventDefault(); var good = true, first = null;
      form.querySelectorAll('[required]').forEach(function (f) {
        var fl = f.closest('.fld'), bad = !f.checkValidity() || !String(f.value).trim();
        if (fl) fl.classList.toggle('bad', bad); if (bad) { good = false; first = first || f; }
      });
      if (!good) { first.focus(); return; } onOk();
    });
    form.addEventListener('input', function (e) { var fl = e.target.closest('.fld'); if (fl) fl.classList.remove('bad'); });
  }

  /* ---------- Page: planner ---------- */
  function pagePlanner() {
    var form = document.getElementById('planner'); if (!form) return;
    var steps = form.querySelectorAll('.step'), dots = document.querySelectorAll('.stepper li'), cur = 0, DK = 'sg_planner_draft';
    function show(i, init) {
      cur = i;
      steps.forEach(function (s, k) { s.classList.toggle('on', k === i); });
      dots.forEach(function (d, k) { d.classList.toggle('on', k === i); d.classList.toggle('done', k < i); if (k === i) d.setAttribute('aria-current', 'step'); else d.removeAttribute('aria-current'); });
      if (i === 3) renderSummary();
      form.querySelector('[data-next]').hidden = (i === 3);
      form.querySelector('[data-prev]').hidden = (i === 0);
      var nb = form.querySelector("[data-next]"); nb.firstChild.textContent = ["Next: Gifting Needs ", "Next: Budget ", "Next: Preferences ", ""][i];
      var top = document.querySelector(".stepper"); if (top && !init) window.scrollTo({ top: top.getBoundingClientRect().top + window.scrollY - 100, behavior: 'smooth' });
    }
    function stepValid(i) {
      var good = true, first = null;
      steps[i].querySelectorAll('[required]').forEach(function (f) { var fl = f.closest('.fld'), bad = !f.checkValidity() || !String(f.value).trim(); if (fl) fl.classList.toggle('bad', bad); if (bad) { good = false; first = first || f; } });
      var grp = steps[i].querySelector('[data-need-one]');
      if (grp) { var any = grp.querySelectorAll('input:checked').length > 0; grp.closest('.fld').classList.toggle('bad', !any); if (!any) { good = false; first = first || grp.querySelector('input'); } }
      if (!good && first) first.focus(); return good;
    }
    form.addEventListener('click', function (e) {
      if (e.target.closest('[data-next]')) { if (stepValid(cur)) show(cur + 1); }
      if (e.target.closest('[data-prev]')) show(cur - 1);
      if (e.target.closest('[data-save]')) { var d = {}; new FormData(form).forEach(function (v, k) { (d[k] = d[k] || []).push(v); }); try { localStorage.setItem(DK, JSON.stringify(d)); } catch (x) {} toast('Progress saved', 'Come back any time to continue your plan.', false); }
    });
    form.addEventListener('input', function (e) { var fl = e.target.closest('.fld'); if (fl) fl.classList.remove('bad'); });
    try { var d = JSON.parse(localStorage.getItem(DK) || 'null'); if (d) Object.keys(d).forEach(function (k) { form.querySelectorAll('[name="' + k + '"]').forEach(function (f) { if (f.type === 'checkbox' || f.type === 'radio') f.checked = d[k].indexOf(f.value) > -1; else f.value = d[k][0]; }); }); } catch (x) {}
    function renderSummary() {
      var l = load(), s = document.getElementById('wl-summary');
      s.innerHTML = l.length ? '<b>Gifts from your wishlist (' + l.length + ')</b><ul>' + l.map(function (x) { var p = byId(x.id); return '<li>' + esc(p ? p.name : x.id) + ' — qty ' + x.qty + '</li>'; }).join('') + '</ul><a href="wishlist.html" class="linkbtn" style="padding:0">Edit wishlist</a>' : '<b>No wishlist items yet.</b> <a href="collections.html" class="linkbtn" style="padding:0">Browse collections</a> — or just submit and we will curate for you.';
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault(); if (!stepValid(3)) return;
      var d = {}; new FormData(form).forEach(function (v, k) { (d[k] = d[k] || []).push(v); });
      var ref = wlRef(), req = { ref: ref, plan: d, wishlist: load() };
      try { var all = JSON.parse(localStorage.getItem('sg_requests') || '[]'); all.push(req); localStorage.setItem('sg_requests', JSON.stringify(all)); localStorage.removeItem(DK); } catch (x) {}
      /* TODO: POST `req` to the real planner endpoint / CRM when the backend is connected. */
      form.hidden = true; document.querySelector('.stepper').hidden = true;
      var ok = document.getElementById('plan-ok'); ok.hidden = false; ok.querySelector('.ref').textContent = 'Reference: ' + ref;
      window.scrollTo({ top: ok.getBoundingClientRect().top + window.scrollY - 120, behavior: 'smooth' });
    });
    show(0, true);
  }

  /* ---------- Reveal ---------- */
  function reveal() {
    var els = document.querySelectorAll('.reveal'); if (!('IntersectionObserver' in window)) { els.forEach(function (e) { e.classList.add('in'); }); return; }
    var io = new IntersectionObserver(function (en) { en.forEach(function (x) { if (x.isIntersecting) { x.target.classList.add('in'); io.unobserve(x.target); } }); }, { threshold: .1 });
    els.forEach(function (e) { io.observe(e); });
  }

  document.addEventListener('DOMContentLoaded', function () {
    initLayout(); pageHome(); pageCollections(); pageProduct(); pageWishlist(); pagePlanner(); reveal();
    document.querySelectorAll('[data-icon]').forEach(function (e) { e.innerHTML = I[e.getAttribute('data-icon')] || ''; });
    document.querySelectorAll('[data-art]').forEach(function (e) { var a = e.getAttribute('data-art').split(':'); e.innerHTML = art(a[0], a[1]); });
    window.addEventListener('storage', refreshCount);
  });
  window.SG = { toggle: toggle };
})();
