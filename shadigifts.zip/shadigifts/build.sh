#!/bin/bash
# usage: bash build.sh — assembles src/<page>.body (line1 title, line2 desc, line3 page key) into <page>.html
cd "$(dirname "$0")"
for f in src/*.body; do
  n=$(basename "$f" .body)
  T=$(sed -n 1p "$f") D=$(sed -n 2p "$f") P=$(sed -n 3p "$f") \
  perl -0pe 's/\@TITLE\@/$ENV{T}/g; s/\@DESC\@/$ENV{D}/g; s/\@PAGE\@/$ENV{P}/g' src/head.part > "$n.html"
  tail -n +4 "$f" | perl -0pe 'BEGIN{open L,"src/leaf.part"; local $/; $l=<L>; open H,"src/how.part"; $h=<H>; chomp $l; chomp $h} s/\@LEAF\@/$l/g; s/\@HOW\@/$h/g' >> "$n.html"
  cat src/tail.part >> "$n.html"
done
echo built
